package ceka.hyf.WSNC;


import ceka.core.Dataset;
import ceka.core.Example;
import ceka.converters.FileLoader;
import ceka.converters.FileSaver;
import ceka.consensus.MajorityVote;

import ceka.noise.ClassificationFilter;

import ceka.noise.PolishingLabels;
import ceka.noise.SelfTrainCorrection;
import ceka.noise.avnc.AdaptiveClassificationFilter;
import ceka.noise.avnc.VoteCorrection;
import ceka.noise.avnc.WorkerStat;
import ceka.noise.clustering.ClusterCorrection;
import ceka.hyf.DataProcessing.DataProcessing;
import ceka.hyf.IDNC.IDNC;
import ceka.hyf.noise.CENC;
import ceka.hyf.noise.CTNC;
import ceka.hyf.noise.EBMNC;
import ceka.hyf.noise.RNC;
import ceka.utils.DatasetManipulator;
import ceka.utils.Stochastics;
import weka.classifiers.Classifier;
import weka.classifiers.lazy.IBk;
import weka.classifiers.trees.J48;
import weka.clusterers.Clusterer;
import weka.clusterers.SimpleKMeans;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.ReplaceMissingValues;

import java.io.FileOutputStream;
import java.io.File;
import java.io.PrintStream;

import org.apache.log4j.PropertyConfigurator;

public class noiseTestReal {

	private static String dataDir = "D:\\CekaSpace\\MyCeka\\data\\real-world\\";
	private static String responseFix = ".response.txt";
	private static String goldFix = ".gold.txt";
	private static String arffxFix = ".arffx";
	private static String arffFix = ".arff";
	
	private static int t_num=10;
	
	
	public static int max(int[] counts) throws Exception{
		int maxCount=counts[0];
		for(int i=0;i<counts.length;i++) {
			if(counts[i]>maxCount) maxCount=counts[i];
		}
		return maxCount;
	}
	
	public static double calculateWeight(Example example,int numOfCategories) throws Exception{
		int[] counts=new int[numOfCategories];
		
		for(int i=0;i<example.getMultipleNoisyLabelSet(0).getLabelSetSize();i++)
			counts[example.getMultipleNoisyLabelSet(0).getLabel(i).getValue()]++;
		
		return (double)(max(counts))/(example.getMultipleNoisyLabelSet(0).getLabelSetSize());
	}
	
	public static double[] calculateWeights(Dataset dataset) throws Exception{
		double[] weights=new double[dataset.getExampleSize()];
		
		for(int i=0;i<dataset.getExampleSize();i++) {
			Example example=dataset.getExampleByIndex(i);
			weights[i]=calculateWeight(example,dataset.getCategorySize());
		}
		
		return weights;
	}

	public static void main(String[] args)
	{
		PropertyConfigurator.configure("D:\\CekaSpace\\Ceka\\lib\\log4j.properties");
		
		//��ʵ
		String[] names = {"income94L10","music_genre","labelme"};

		
		double meanNoiseRatio_MV=0.0;
		double meanNoiseRatio_PL=0.0;
		double meanNoiseRatio_STC=0.0;
		double meanNoiseRatio_CC=0.0;
		double meanNoiseRatio_AVNC=0.0;
		double meanNoiseRatio_CENC=0.0;
		double meanNoiseRatio_LDNC=0.0;
		double meanNoiseRatio_new=0.0;
		
		
		try {
			//��ʵ
			String resultPath="D:\\CekaSpace\\MyCeka\\result\\WSNC\\real\\result.txt";
			FileOutputStream f=new FileOutputStream(new File(resultPath));
			PrintStream result=new PrintStream(f);
			result.format("%-20s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s", "Dataset","MV","PL","STC","CC","AVNC","CENC","LDNC","WSNC");
			result.println();

			
			for(int i=0;i<names.length;i++)
			{
				String responsePath = dataDir + names[i] + "\\" + names[i] + responseFix;
				String goldPath = dataDir + names[i] + "\\" + names[i] + goldFix;
				String arffxPath = dataDir + names[i] + "\\" + names[i] + arffxFix;
				String arffPath = dataDir + names[i] + "\\" + names[i] + arffFix;				

				
				//��ʵ
				Dataset dataset;
				try {
					dataset = FileLoader.loadFileX(responsePath, goldPath, arffxPath);
				} catch (Exception e) {
					// TODO Auto-generated catch block
//					e.printStackTrace();
					dataset = FileLoader.loadFile(responsePath, goldPath, arffPath);
				}
				
				double noiseRatio_MV=0.0;
				double noiseRatio_PL=0.0;
				double noiseRatio_STC=0.0;
				double noiseRatio_CC=0.0;
				double noiseRatio_AVNC=0.0;
				double noiseRatio_CENC=0.0;
				double noiseRatio_LDNC=0.0;
				double noiseRatio_new=0.0;
				
				double runTime_MV=0;
				double runTime_PL=0;
				double runTime_STC=0;
				double runTime_CC=0;
				double runTime_AVNC=0;
				double runTime_CENC=0;
				double runTime_LDNC=0;
				double runTime_new=0;
				
				
				double startTime=0;
				double endTime=0;
				
				//��10����ƽ��ֵ
				for(int t=0;t<t_num;t++) {
					
					//MV
					startTime=System.currentTimeMillis();
					MajorityVote mv=new MajorityVote();
					mv.doInference(dataset);
					endTime=System.currentTimeMillis();
					noiseRatio_MV+=DataProcessing.getNoiseRatio(dataset);
					runTime_MV+=(endTime-startTime)/1000.0;
					
					//PL
					Dataset tempDataset1=DataProcessing.copyDataset(dataset);
					startTime=System.currentTimeMillis();
					Classifier classifier1=new J48();
					PolishingLabels pl=new PolishingLabels(classifier1);
					Dataset dataset_corrected_pl=pl.polishLabels(tempDataset1);
					endTime=System.currentTimeMillis();
					noiseRatio_PL+=DataProcessing.getNoiseRatio(dataset_corrected_pl);
					runTime_PL+=(endTime-startTime)/1000.0;
					System.out.println("PL Completed!");
					
					
					//STC
					Dataset tempDataset2=DataProcessing.copyDataset(dataset);
					startTime=System.currentTimeMillis();
					Classifier[] classifiers1=new Classifier[1];
					classifiers1[0]=new J48();
					ClassificationFilter cf1=new ClassificationFilter(10);
					cf1.filterNoise(tempDataset2, classifiers1);
					Dataset cleanSet1=cf1.getCleansedDataset();
					Dataset noiseSet1=cf1.getNoiseDataset();
					
					Dataset[] tempdata=new Dataset[2];
					SelfTrainCorrection stc=new SelfTrainCorrection(cleanSet1,noiseSet1,0.8);
					Classifier classifier2=new J48();
					tempdata=stc.correction(classifier2);
					DatasetManipulator.addAllExamples(tempdata[0], tempdata[1]);
					endTime=System.currentTimeMillis();
					noiseRatio_STC+=DataProcessing.getNoiseRatio(tempdata[0]);
					runTime_STC+=(endTime-startTime)/1000.0;
					System.out.println("STC Completed!");
					
					//CC
					Dataset tempDataset3=DataProcessing.copyDataset(dataset);
					startTime=System.currentTimeMillis();
					int numClusters=10;
					Clusterer[] clusterers=new Clusterer[numClusters];
					for(int c=0;c<numClusters;c++)
					{
						int k=(int)(((double)(c+1)/(double)(numClusters))*(tempDataset3.getExampleSize()/2.0));
						if(c==0) k=k+2;
						SimpleKMeans simpleKMeans=new SimpleKMeans();
						simpleKMeans.setMaxIterations(200);
						simpleKMeans.setNumClusters(k);
						clusterers[c]=simpleKMeans;
					}
					
					String tempPath="D:\\CekaSpace\\MyCeka\\data\\output\\WSNC\\"+names[i]+".arff";
					FileSaver.saveDatasetArff(tempDataset3, tempPath);
					ClusterCorrection cc=new ClusterCorrection(tempDataset3,tempPath,clusterers);
					Dataset dataset_corrected_cc=cc.correction();
					endTime=System.currentTimeMillis();
					noiseRatio_CC+=DataProcessing.getNoiseRatio(dataset_corrected_cc);
					runTime_CC+=(endTime-startTime)/1000.0;
					System.out.println("CC Completed!");
	
			
					//AVNC
					Dataset tempDataset4=DataProcessing.copyDataset(dataset);
					startTime=System.currentTimeMillis();
					WorkerStat workerStat=new WorkerStat();
					double estimatedMeanProb=workerStat.calculateEstimatedMeanAcc(dataset);
					double integratedCorrectProb=Stochastics.binomialIntegration(9, estimatedMeanProb);
					int nfold=10;
					int nModel=5;
					AdaptiveClassificationFilter acf=new AdaptiveClassificationFilter(nfold,nModel);
					acf.setMinEstimatedNoiseProportion(1-integratedCorrectProb);
					acf.setMaxEstimatedNoiseProportion(1-estimatedMeanProb);
					
					Classifier[] classifiers2=new Classifier[5];
					for(int k=0;k<5;k++)
						classifiers2[k]=new J48();
					acf.filterNoise(tempDataset4, classifiers2);
					Dataset cleanSet2=acf.getCleansedDataset();
					Dataset noiseSet2=acf.getNoiseDataset();
					Dataset[] highDatasets=acf.getHighQualityDatasets();
					
					VoteCorrection corrector=new VoteCorrection();
					corrector.correct(noiseSet2, highDatasets, classifiers2, (int)(highDatasets.length*0.5));
					for(int k=0;k<noiseSet2.getExampleSize();k++)
						cleanSet2.addExample(noiseSet2.getExampleByIndex(k));
					endTime=System.currentTimeMillis();
					noiseRatio_AVNC+=DataProcessing.getNoiseRatio(cleanSet2);
					runTime_AVNC+=(endTime-startTime)/1000.0;
					System.out.println("AVNC Completed!");
					
					//CENC
					Dataset tempDataset6=DataProcessing.copyDataset(dataset);
					startTime=System.currentTimeMillis();
					CENC cenc=new CENC(10,0.1);
					Classifier classifier3=new J48();
					Dataset dataset_corrected_cenc=cenc.cenc(tempDataset6, classifier3);
					endTime=System.currentTimeMillis();
					noiseRatio_CENC+=DataProcessing.getNoiseRatio(dataset_corrected_cenc);
					runTime_CENC+=(endTime-startTime)/1000.0;
					System.out.println("CENC Completed!");
					
					
					//LDNC
					Dataset dataset9=DataProcessing.copyDataset(dataset);
					startTime=System.currentTimeMillis();
					EBMNC ldnc=new EBMNC(0.2);
					Classifier classifier9=new J48();
					Dataset dataset_corrected_ldnc= ldnc.ebmnc(dataset9, classifier9);
					endTime=System.currentTimeMillis();
					runTime_LDNC+=(endTime-startTime)/1000.0;
					noiseRatio_LDNC += DataProcessing.getNoiseRatio(dataset_corrected_ldnc);
					System.out.println("LDNC Completed!");
					
					
					
					//my new
					Dataset tempDataset11=DataProcessing.copyDataset(dataset);
					startTime=System.currentTimeMillis();
					
					WSNC wwnc=new WSNC();
					Dataset dataset_corrected_wdnc = wwnc.WSNC(tempDataset11,5);
					endTime=System.currentTimeMillis();
					noiseRatio_new+=DataProcessing.getNoiseRatio(dataset_corrected_wdnc);
					runTime_new+=(endTime-startTime)/1000.0;
					System.out.println("new Completed!");
					
					System.out.println("time "+(t+1)+"\t Completed!");
				}
				
				noiseRatio_MV/=t_num;
				noiseRatio_PL/=t_num;
				noiseRatio_STC/=t_num;
				noiseRatio_CC/=t_num;
				noiseRatio_AVNC/=t_num;
				noiseRatio_CENC/=t_num;
				noiseRatio_LDNC/=t_num;
				noiseRatio_new/=t_num;
				
				meanNoiseRatio_MV+=noiseRatio_MV;
				meanNoiseRatio_PL+=noiseRatio_PL;
				meanNoiseRatio_STC+=noiseRatio_STC;
				meanNoiseRatio_CC+=noiseRatio_CC;
				meanNoiseRatio_AVNC+=noiseRatio_AVNC;
				meanNoiseRatio_CENC+=noiseRatio_CENC;
				meanNoiseRatio_LDNC+=noiseRatio_LDNC;
				meanNoiseRatio_new+=noiseRatio_new;
				
				
				result.format("%-20s %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f", names[i],noiseRatio_MV,noiseRatio_PL,noiseRatio_STC,noiseRatio_CC,noiseRatio_AVNC,noiseRatio_CENC,noiseRatio_LDNC,noiseRatio_new);
				result.println();
				System.out.println(names[i]+" complete!");
				
			}
			meanNoiseRatio_MV/=names.length;
			meanNoiseRatio_PL/=names.length;
			meanNoiseRatio_STC/=names.length;
			meanNoiseRatio_CC/=names.length;
			meanNoiseRatio_AVNC/=names.length;
			meanNoiseRatio_CENC/=names.length;
			meanNoiseRatio_LDNC/=names.length;
			meanNoiseRatio_new/=names.length;
			
			result.format("%-20s %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f", "Mean",meanNoiseRatio_MV,meanNoiseRatio_PL,meanNoiseRatio_STC,meanNoiseRatio_CC,meanNoiseRatio_AVNC,meanNoiseRatio_CENC,meanNoiseRatio_LDNC,meanNoiseRatio_new);
			result.println();
			result.close();
			
			
			System.out.println("Complete!!!");
			
		}catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
	
	
}